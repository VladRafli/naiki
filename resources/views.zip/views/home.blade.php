@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center"> I
        <div class="col-md-12 mb-4">
            <img src="{{ url('images/logo.png') }}" class="rounded mx-auto d-block" width="700" alt="">
        </div>
        $foreach($items as $item)
        <div class="col-md-4">
            <div class="card">
              <img src="{{ url('uploads') }}/{{ $item->gambar }}" class="card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title">{{ $item->nama_barang }}</h5>
                <p class="card-text">
                    <strong>Harga :</strong> Rp. {{ number_format($item->harga_barang)}} <br>
                    <strong>Stok :</strong> {{ $item->stok_barang }} <br>
                    <hr>
                    <strong>Keterangan :</strong> <br>
                    {{ $item->detail_barang }} 
                </p>
                <a href="{{ url('pesan') }}/{{ $item->id }}" class="btn btn-primary"><i class="fa fa-shopping-cart"></i> Pesan</a>
              </div>
            </div> 
        </div>
        @endforeach
    </div>
</div>
@endsection